Robust Photometric Stereo Using Sparse Bayesian Regression
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp, dvwipf@microsoft.com, yasumat@microsoft.com
% Date: 20121125

This package contains codes and a synthetic dataset used in the paper.

= dataset =
images: Synthesized bunny images (32 bit-grayscale-portable-float-map format and image size is 256x256)
lighting: Lighting directions used for rendering
mask.png: Mask image indicating the object region
imgNormal: Ground-truth normal map

=�@useage =
Please run "main.m" in this package.

This codes have two modes, 

1. Calcuralte surface normals for every pixels and show normal maps / error maps.

If 'pos' in main.m is set as [0 0], the codes recover surface normals for every pixels. Then, recovered normal maps and error maps (in degrees) are illustrated. In this mode, you can compare our method with other methods (LS, L1, SBL, Biquadratic) and you can see which pixels are troublesome by the visual inspection of the error map. 

2. Analysis for the specific pixel

If 'pos' in main.m is set as the specific position (e.g. [128 128]), this program only calcurates for the specified pixel (therefore, you can acquire the result very quickly) and show the distributions of recovered 2-d plots (I, n^Tl) and picewise linear function by PL-SBL and PL-LS. The distributions of (I, n^Tl) from the ground truth surface normal are also plotted in the figure (green plots). From the figure, you can see how the estimation was failed/suceeded. 


= Example of Useage =
1. Set numImages =�@40, shadow_cutoff = 0 (skip shadows), noise =�@0 (no noises), lambda =�@0 (hard constraint problem), APPLY_LS =�@1, APPLY_PLSBL =�@1
2. Run main.m
3. See error maps and find the trobuled pixels
4. Set 'pos' by the postion of the pixel you found, set APPLY_LS =�@0 and then run main.m
5. You can see the distributions of observations
