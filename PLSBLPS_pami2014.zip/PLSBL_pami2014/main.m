% Robust Photometric Stereo Using Sparse  Bayesian Regression for General Diffusive Surface Recovery(PAMI 2014)
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp
% Last modified 26 Nov. 2014

close all;
clear all;

addpath include
% chose the method(s) use?(1:yes, else:no)
APPLY_LS = 1; % least-squares
APPLY_PLLS = 1; % LS-based pieacewise linear regression
APPLY_PLSBL = 1; % SBL-based piecewise linear sparse regression

numImages        =  40; % The number of images used for the experiment (must be less than the number of images in the folder)
shadow_cutoff    = 0; % The thresholding parameter for shadow removal (e.g., in case shadow_cutoff < 0, it uses all pixels)
noise            = 0; % The ratio of random noises (gaussian additive noises, the variance can be changed in setup.m)
lambda      = 0; % Regularization weight for Sparse Regression (when lambda = 0, it uses the hard constraint;no diffusive errors)
sigma_a = 1.0; % Slant variance for picewise-linear sparse regression (see min_SBL_error_pl.m in details)
num_segments = 3; % Number of sub-functions for piecewise-linear sparse regression (the number of observations for each segment is decided by this parameter)
pos = [0 0];
% pos = [100 100]; % If you would like to calcurate normals for every pixels, please comment it out (use it for the analysis of a specific pixel).



%% Initialization
setup; % Loading images, lightings, mask image and ground truth normals

%% Applying Photometric Stereo
applyPS; % Apply methods indicaded above (LS, BQ, L1, SBL, PLLS, PLSBL)

%% Showing Results
if pos == [0 0]
    show_results; % view results (recovered normal map and error map)
end

%% Showing per-pixel results (Convinient for analysis: Use it when you would like see what was going on for the specific pixel. Note that it currently works for PL-LS and PL-SBL)
if pos ~= [0 0]

    if APPLY_PLLS
        per_pix_analysis(10, shadow_cutoff, I_ALL, N_PLLS, N_true, a_PLLS, light_true, m, pos, 'PLLS');
    end

    if APPLY_PLSBL
        per_pix_analysis(11, shadow_cutoff, I_ALL, N_PLSBL, N_true, a_PLSBL, light_true, m, pos, 'PLSBL');
    end

end
