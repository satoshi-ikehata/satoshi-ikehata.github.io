% Robust Photometric Stereo Using Sparse Regression for General Diffusive Surface Recovery(PAMI 2012)
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp, dvwipf@microsoft.com,
% yasumat@microsoft.com,aizawa@hal.t.u-tokyo.ac.jp

%% Setting the parameters
MATERIAL         = 'images';
IMAGES           = sprintf('%s/%s.pfm', MATERIAL, '%02d');
LIGHTINGS        = sprintf('%s/L40.mat',MATERIAL);
MASK             = sprintf('%s/mask.png',MATERIAL);
TRUENORMAL       = sprintf('%s/imgNormal.mat',MATERIAL);


%% Loading lightings
load(LIGHTINGS);
if(size(L,2) == 3)
    L = L';
end

if(L(3,1) < 0)
    L = -L;   
end

light_true = L(:,(1:numImages));

%% Loading the true normal map
load(TRUENORMAL);
N_true = zeros(size(imgNormal));
N_true(:, :, 1)= imgNormal(:,:,1);
N_true(:, :, 2)= imgNormal(:,:,2);
N_true(:, :, 3)= imgNormal(:,:,3);


%% Loading the mask image
mask = double(imread(MASK))./255;
mask = mask(:,:,1);
[height, width] = size(mask);
m = find(mask(:)==1);

%% Loading images (.pfm)
I = zeros(length(m), numImages);
I_ALL = zeros(width*height, numImages); % used for per-pixel check (optional)

for i = 1 : numImages
        img = readPFM(sprintf(IMAGES, i));  
        imggray = flipud(rgb2gray(img));

        if(noise > 0)
        imgnoise = Box_Muller(size(imggray),0,0.01,noise);      
        I_ALL(:, i) = imggray(:) + imgnoise(:);
        imgnoise = imgnoise(m);
        imggray = imggray(m);
        imggray = imggray + imgnoise;
        else
        I_ALL(:, i) = imggray(:);
        imggray = imggray(m);
        end       
        
        I(:, i) = imggray; 
end
