% x = normal coefficients and slants parameters at a given location to be estimated, 
% A = the data matrix, 
% b = the measurements, and
% lambda = the coefficient of the regularization term.

function [x, error] = min_SBL_error_pl(A,b,sigma_a) 
% [x, error] = min_SBL_error_pl(A,b,sigma_a) % Sparse Basian Learning for piecewise linear regression (hard constraint problem)

MAX_ITERS   = 20;  % Maximum number of iterations
ERR_THR     = 1e-8; % For stopping criteria
GAMMA_THR   = 1e-8; % For numerical stability
sigma_n = 1.0e-6;
sigma_a = 1/sigma_a;
[n,m] = size(A);
sigma = [sigma_a*ones(m-3,1);sigma_n*ones(3,1)]; % Variance for each (unknown) parameter
sig_eye_inv = diag(sigma.^-1);
sig_eye = diag(sigma);

gamma = ones(n,1);
x_old = 1000*ones(m,1);
gamma = ones(n,1);

for i = 1:MAX_ITERS;
    
    W = diag(1./gamma);
    W(n,n) = 1.0e6; % Set large constant value to enforce sum_i a_i = 1
    x = (sig_eye + A'*W*A)\(A'*W*b);
    
    if (norm(x-x_old) < ERR_THR)
        break;
    end;
    

    
    x_old = x;
    error = b - A*x;

    
    Xi = (sig_eye + A'*W*A)\A';
    Sigma_e_diag = sum(A.*Xi',2); 
    
    gamma = error.^2 + Sigma_e_diag; 
    gamma = max(gamma,GAMMA_THR);
end;

return;