function [nml, a, time] = pms_pl_sr(observation, lightings, mask, threshold, lambda, NUM_SEGMENTS, sigma_a, pos, method)
% [nml, a, time] = pms_pl_sr(observation, lightings, mask, threshold, lambda, NUM_SEGMENTS, sigma_a, pos, method)
% Estimate surface normals using picewise linaer (sparse) regressions (PL-LS, PL-SBL)

[height, width] = size(mask);
m = find(mask(:)==1);
[masklength, numImages]  = size(observation);

n_x = zeros(height*width, 1); % Recovered surface normals (nx)
n_y = zeros(height*width, 1); % Recovered surface normals (ny)
n_z = zeros(height*width, 1); % Recovered surface normals (nz)
a = zeros(height*width, NUM_SEGMENTS);

target_i = 0;
if pos ~= [0 0] % For analytical mode
X = pos(1); Y = height - pos(2) + 1;
target_i = find(m == (X - 1)*height + Y);
end

tic;
for i = 1 : length(m)
    
   
    if target_i ~= 0 & i ~= target_i % For analytical mode
        continue;
    end
        
    obs = observation(i,:)';
    Omega = find(obs>threshold);
    obs = obs(Omega);
    L = lightings';
    L = L(Omega,:)';

    %% Align obervations in increasing order 
    index = zeros(length(obs), 2);
    index(:,1) = [1:length(obs)]';
    index(:,2) = obs;
    index = sortrows(index,2);
    obs_ordered = index(:,2); % align observations in increasing order
    light_ordered = L(:, index(:,1))'; % align lightings in the same order of observations

    %% Calcurate number of observations in each line segment
    if(NUM_SEGMENTS > 0)
    num_segments = NUM_SEGMENTS;
    if floor(length(index)/num_segments) <= 0
        disp(['Invailed number of segments!']);
        n_x(m(i))= 0;
        n_y(m(i))= 0;
        n_z(m(i))= 1;
        continue;
    end
    obs_in_seg = floor(length(index)/num_segments); % observations per line segment
    else 
        disp(['Invailed number of segments!']);
        n_x(m(i))= 0;
        n_y(m(i))= 0;
        n_z(m(i))= 1;
        continue;
    end

    %% Set breaking points
    junction = zeros(num_segments+1, 1);        
    id = 1:length(obs_ordered);
    junction(1) = 0;
    junction(2:num_segments) = obs_ordered(obs_in_seg.*(1:(num_segments-1)));
    junction(num_segments+1) = 1.0;

    %% Set data matrix
    B_ = zeros(length(obs_ordered), num_segments + 3);
    B_(length(obs_ordered) + 1, 1:num_segments) = 1.0;
    y = zeros(length(obs_ordered) + 1, 1);
    y(length(obs_ordered) + 1,1) = 1.0;     
    B_(1:length(obs_ordered), num_segments+1: num_segments + 3) = -light_ordered;

    for j = 1 : num_segments
        k = 0;
        id = find( obs_ordered >= junction(j) & obs_ordered < junction(j+1) );
        while j - k - 1 >= 1
        B_(id, j-k-1) = junction(j-k) - junction(j-k-1);
            k = k + 1;
        end
        B_(id, j) = obs_ordered(id,1) - junction(j);
    end

    %% Solve problem
    if method == 1 % Apply PL-SBL based photometric stereo
        if lambda == 0
            [npp error] = min_SBL_error_pl(B_, y, sigma_a); % No diffusive errors
        else
            [npp error] = min_SBL_error_regularizer_pl(B_, y, sigma_a, lambda); % With diffusive errors
        end
    end

    if method == 0 % Apply PL-LS based photometric stereo
        npp = B_\y;
        error = y - B_*npp;
    end

    n = npp(num_segments+1: num_segments+3);
    a(m(i),:) = npp(1:num_segments);
    norm_n = norm(n);
    n = n/norm_n; % surface normal
    a(m(i),:) = a(m(i),:)/norm_n; % slants

    n_x(m(i))= n(1);
    n_y(m(i))= n(2);
    n_z(m(i))= n(3);
end


n_x = reshape(n_x, height, width);
n_y = reshape(n_y, height, width);
n_z = reshape(n_z, height, width);
a = reshape(a, height, width, NUM_SEGMENTS);

nml = zeros(height, width, 3);
nml(:, :, 1) = n_x;
nml(:, :, 2) = n_y;
nml(:, :, 3) = n_z;
nml(isnan(nml)) = 0;
time = toc; 

end

