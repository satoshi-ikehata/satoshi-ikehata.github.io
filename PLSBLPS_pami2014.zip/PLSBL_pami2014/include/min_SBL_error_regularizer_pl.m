% x = normal coefficients at a given location to be estimated, 
% A = the lighting location matrix, 
% b = the measurements, and
% lambda = the coefficient of the regularization term.

function [x, error] = min_SBL_error_regularizer_pl(A,b, sigma_a, lambda) 
% min_SBL_error_regularizer_pl(A,b, sigma_a, lambda) Sparse Basian Learning for pecewise linear sparse regression with softconstraint

MAX_ITERS   = 20;    % Maximum number of iterations
ERR_THR     = 1e-8;   % For stopping criteria
GAMMA_THR   = 1e-8;   % For numerical stability
sigma_n = 1.0e6;  % Source variance
[n,m] = size(A);
sigma = [sigma_a*ones(m-3,1);sigma_n*ones(3,1)];
sig_eye = diag(sigma.^-1);
sig_eye2 = diag(sigma);

e_old = 1000*ones(n,1);
gamma = ones(n,1);

for i = 1:MAX_ITERS;
    
    Gamma_e = diag(gamma);
    test = ones(n,1);
    test(n,1) = 1.0e-8;
    Sigma_d = gamma + lambda*test;
    invD = diag(1./Sigma_d);
  
    sig_ge = (sig_eye + A'*invD*A)\(A'*invD);
    g_e = (invD - invD*A*sig_ge)*b;

%     g_e = (Gamma_e + lambda*eye(n) + sigma*A*A')\b; % above equation is deformation of this by matrix inversion lemma    
    e = Gamma_e*g_e;
        
    if (norm(e-e_old) < ERR_THR)
        break;        
    end;
    
    e_old = e;    
    
    Ei = (invD - invD*A*sig_ge)*Gamma_e;   
    Sigma_e = Gamma_e - Gamma_e*Ei;
    gamma = diag(e*e') + diag(Sigma_e);
    gamma = max(gamma, GAMMA_THR);
    gamma(n,1) = 0;% Set zero to enforce sum_i a_i = 1
    
end;

test = eye(n);
test(n,n) = 0; % enforce the sum constraint by weightind the diffuse term
Xi = (lambda*test + Gamma_e + A*sig_eye2*A')\b;

x = sig_eye2*A'*Xi;
error = e;

return;