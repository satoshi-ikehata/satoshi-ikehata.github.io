% Robust Photometric Stereo Using Sparse   Bayesian Regression for General Diffusive Surface Recovery(PAMI 2012)
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp
% Last modified 26 Nov. 2012

if (APPLY_LS)
view_nml_error(1, 'LS',  N_LS, N_true, m)
end

if (APPLY_PLLS)
view_nml_error(5, 'PLLS', N_PLLS, N_true, m);
end

if (APPLY_PLSBL)
view_nml_error(6, 'PLSBL', N_PLSBL, N_true, m);
end