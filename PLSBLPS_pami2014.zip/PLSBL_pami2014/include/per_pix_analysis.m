function [ output_args ] = per_pix_analysis(figid, threshold, I_ALL, nml, n_true, a, lightings, m, pos, method)
% Check perpixel results (show distributions of observations and recovered piecewise linear function) 

if length(pos) ~= 2
disp(['(pos) must be 2 dimensional vector']);
return;
end

% Color-map
colorval = zeros(10, 3);
colorval(1, :) = [0.5, 0, 0.5];
colorval(2, :) = [0, 0.5, 0.5];
colorval(3, :) = [0.5, 0.5, 0];
colorval(4, :) = [1.0, 0, 0.0];
colorval(5, :) = [0, 1.0, 0.0];
colorval(6, :) = [0.0, 0.0, 1.0];
colorval(7, :) = [1.0, 0.5, 0.5];
colorval(8, :) = [0.5, 1.0, 0.5];
colorval(9, :) = [0.5, 0.5, 1.0];
colorval(10, :) = [0.5, 0, 0.5];
colorval(11, :) = [0, 0.5, 0.5];
colorval(12, :) = [0.5, 0.5, 0];
colorval(13, :) = [1.0, 0, 0.0];
colorval(14, :) = [0, 1.0, 0.0];
colorval(15, :) = [0.0, 0.0, 1.0];
colorval(16, :) = [1.0, 0.5, 0.5];
colorval(17, :) = [0.5, 1.0, 0.5];
colorval(18, :) = [0.5, 0.5, 1.0];

[height, width, num_segments] = size(a);

X = pos(1); Y = height - pos(2) + 1;
index = (X - 1)*height + Y;
obs = I_ALL(index,:)';


Omega = find(obs>threshold);
obs = obs(Omega);
L = lightings(:, Omega);
n = reshape(nml(Y, X, :), 3, 1);
nt = reshape(n_true(Y, X, :), 3, 1);
a = reshape(a(Y, X, :), num_segments, 1);
nl = L'*n;
imax = max(obs);

index = zeros(length(obs), 2);
index(:,1) = [1:length(obs)]';
index(:,2) = obs;
index = sortrows(index,2);

obs_in_seg = floor(length(index)/num_segments); % observations per line segment
obs_ordered = index(:,2); % align observations in increasing order
light_ordered = L(:, index(:,1))'; % align lightings in the same order of observations
nl_true = light_ordered*nt;
junction = zeros(num_segments+1, 1);        
id = 1:length(obs_ordered);
junction(1) = 0;
junction(2:num_segments) = obs_ordered(obs_in_seg.*(1:(num_segments-1)));
junction(num_segments+1) = 1.0;

x_ = cell(1, num_segments);
I_ = cell(1, num_segments);


% display
disp(sprintf('Observations in each line segment is %d', obs_in_seg));
disp(sprintf('Angular error of [%s %s] (%s) is %s', num2str(X), num2str(Y), method, 180*acos(n'*nt)/pi));



%%  % show distributions of [I, nl] and piecewise linear function
figure(figid)
hold on
I_from = 0;
for j = 1 : num_segments
k = 0;

if (j < num_segments)
I_to = I_from + a(j)*(junction(j+1) - junction(j));
else
I_to = I_from + a(j)*(1.0 - junction(j));
end

x = [junction(j) junction(j+1)];
y = [I_from I_to];
I_from = I_to;

plot(x, y, 'Color', colorval(j,:) ,'LineWidth',8)
plot([junction(j) junction(j)], [-1.0 1.0], '--k','LineWidth',2);
axis([0.0,imax,-1.0,1.0])
end

plot(obs, nl, 'bo','LineWidth',1,'MarkerSize',6,'MarkerEdgeColor','k','MarkerFaceColor','w')
axis([0.0,imax,-1.0,1.0])

%%  overay ground truth distributions of [I, nl]

plot(obs_ordered, nl_true, 'bo','LineWidth',1,'MarkerSize',2,'MarkerEdgeColor','k','MarkerFaceColor','g')
axis([0.0,imax,-1.0,1.0])
title(sprintf('%s (%s)', method,  180*acos(n'*nt)/pi))
hold off

end

