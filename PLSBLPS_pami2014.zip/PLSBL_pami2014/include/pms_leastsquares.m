function [nml, a, time] = pms_leastsquares(observation, lightings, mask, threshold)
% [nml, a, time] = pms_leastsquares(observation, lightings, mask, threshold)
% Estimate surface normals using the standard least square method by Woodham (1980)

[height, width] = size(mask);
m = find(mask(:)==1);
[masklength, numImages]  = size(observation);
a = zeros(height*width, 1); % surface albedo
n_xLS = zeros(height*width,1); % recovered normal (nx)
n_yLS = zeros(height*width,1); % recovered normal (ny)
n_zLS = zeros(height*width,1); % recovered normal (nz)

tic;
for i=1 : length(m);
   obs = observation(i,:)';
   index = find(obs > threshold); % shadow removal
   obs = obs(index);
   L = lightings(:,index);
   n = obs'*pinv(L);
   norm_n = norm(n);
   n = n/norm_n;
   n_xLS(m(i)) = n(1);
   n_yLS(m(i)) = n(2);
   n_zLS(m(i)) = n(3);
   a(m(i)) = norm_n;
end;

n_xLS = reshape(n_xLS, height, width);
n_yLS = reshape(n_yLS, height, width);
n_zLS = reshape(n_zLS, height, width);

nml = zeros(height, width, 3);
nml(:, :, 1) = n_xLS;
nml(:, :, 2) = n_yLS;
nml(:, :, 3) = n_zLS;
nml(isnan(nml)) = 0;

time = toc;
end

