function view_nml_error(figid, method, nml, nml_true, m)
% view_nml_error(figid, method, nml, nml_true, m)
% View normal map and error map

figure(figid)
subplot(1,2,1) % Show normal map
imagesc(uint8((nml+1)*128));
title(sprintf('Normal (%s)', method));
axis equal;
axis off;
[meanA, varA, stdA, maxA, angle]  = normalAngleEval(nml_true, nml, m);
disp(['Avarage Anglular error of ',method, '-based method is: ', num2str(meanA)]);
[h, w, c] = size(nml);

subplot(1,2,2) % Show error map
AngleMat = zeros(h*w,1);
AngleMat(m) = angle;
AngleMat = reshape(AngleMat, h, w);

colormap jet(256); %Color lookup table
pcolor(flipud(AngleMat)) 
title(sprintf('Error (%s)',method));
shading flat; 
caxis([0,30]);
colorbar('SouthOutside');
colormap(gray);
axis('square','equal','off');

end

