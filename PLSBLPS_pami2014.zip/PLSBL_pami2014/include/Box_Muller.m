function [x] = Box_Muller(size, mean, sigma, thresh)
x = zeros(size);
rows = size(1);
cols = size(2);
for i = 1 : rows
    for j = 1 : cols
    x1 = rand();
    x2 = rand();
    x3 = rand();
    if(x3 < thresh)
        x(i,j) = sigma*sqrt(-2*log(x1))*sin(2*pi*x2) + mean;
    end
end
end

