% Robust Photometric Stereo Using Sparse Regression for General Diffusive Surface Recovery(PAMI 2012)
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp, dvwipf@microsoft.com,
% yasumat@microsoft.com,aizawa@hal.t.u-tokyo.ac.jp


% Standard PMS 
if (APPLY_LS)
disp(['Applying Standard Linear Photometric Stereo']);
[N_LS, a_LS, time] = pms_leastsquares(I, light_true, mask, shadow_cutoff);
disp(['Elapsed time of LS method is : ', num2str(time), ' sec']);
end

% PL-LS PMS
if (APPLY_PLLS)
disp(['Applying Piecewise Linear Least-squares-based Photometric Stereo']);
[N_PLLS, a_PLLS, time] = pms_pl_sr(I, light_true, mask, shadow_cutoff, [], num_segments, [], pos, 0);
disp(['Elapsed time of PLLS method is : ', num2str(time), ' sec']);
end

% PL-SBL PMS
if (APPLY_PLSBL)
disp(['Applying Piecewise Linear SBL-based Photometric Stereo']);
[N_PLSBL, a_PLSBL, time] = pms_pl_sr(I, light_true, mask, shadow_cutoff, lambda, num_segments, sigma_a, pos, 1);
disp(['Elapsed time of PLSBL method is : ', num2str(time), ' sec']);
end
