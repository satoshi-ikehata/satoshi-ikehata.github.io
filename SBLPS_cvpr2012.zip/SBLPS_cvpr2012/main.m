% Robust Photometric Stereo Using Sparse Regression (CVPR 2012)
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp, dvwipf@microsoft.com, yasumat@microsoft.com
% Date: 20120406

close all;
clear all;

numImages        = 40; % The number of images used for the experiment
shadow_cutoff    = -1; % The thresholding parameter for shadow removal (e.g., in case shadow_cutoff < 0, it uses all pixels) 
noise            = 0.1; % The ratio of random noises
lambda      = 1.0e-8; % Regularization weight for Sparse Regression

%% Initialization
setup;

%% Applying Photometric Stereo


% Standard PMS 
disp(['Applying Standard Photometric Stereo']);
[N_LS, time] = pms_leastsquares(I, light_true, mask, shadow_cutoff);
disp(['Elapsed time of LS method is : ', num2str(time), ' sec']);

% L1 PMS
disp(['Applying L1-based Photometric Stereo']);
[N_L1, time] = pms_sr(I, light_true, mask, shadow_cutoff, lambda, 0);
disp(['Elapsed time of L1 method is : ', num2str(time), ' sec']);

% SBL PMS
disp(['Applying SBL-based Photometric Stereo']);
[N_SBL, time] = pms_sr(I, light_true, mask, shadow_cutoff, lambda, 1);
disp(['Elapsed time of SBL method is : ', num2str(time), ' sec']);

%% Showing Results
[h, w] = size(mask);
figure(1)

subplot(1,2,1)
imagesc(uint8((N_LS+1)*128));
title('Normal (LS)');
axis equal;
axis off;

[meanA_LS, varA_LS, stdA_LS, maxA_LS, angle_LS]  = normalAngleEval(N_true, N_LS, m);
disp(['Avarage Anglular error of least-square-based method is: ', num2str(meanA_LS)]);


subplot(1,2,2)
AngleMat = zeros(h*w,1);
AngleMat(m) = angle_LS;
AngleMat = reshape(AngleMat, h, w);
imagesc(AngleMat);
title('Error (LS)');
axis equal;
axis off;


figure(2)
subplot(1,2,1)
imagesc(uint8((N_L1+1)*128));
title('Normal (L1)');
axis equal;
axis off;

[meanA_L1, varA_L1, stdA_L1, maxA_L1, angle_L1]  = normalAngleEval(N_true, N_L1, m);
disp(['Avarage Anglular error of l1-based method is: ', num2str(meanA_L1)]);

subplot(1,2,2)
AngleMat = zeros(h*w,1);
AngleMat(m) = angle_L1;
AngleMat = reshape(AngleMat, h, w);
imagesc(AngleMat);
title('Error (L1)');
axis equal;
axis off;

figure(3)
subplot(1,2,1)
imagesc(uint8((N_SBL+1)*128));
title('Normal (SBL)');
axis equal;
axis off;

[meanA_SBL, varA_SBL, stdA_SBL, maxA_SBL, angle_SBL]  = normalAngleEval(N_true, N_SBL, m);
disp(['Avarage Anglular error of sbl-based method is: ', num2str(meanA_SBL)]);

subplot(1,2,2)
AngleMat = zeros(h*w,1);
AngleMat(m) = angle_SBL;
AngleMat = reshape(AngleMat, h, w);
imagesc(AngleMat);
title('Error (SBL)');
axis equal;
axis off;

