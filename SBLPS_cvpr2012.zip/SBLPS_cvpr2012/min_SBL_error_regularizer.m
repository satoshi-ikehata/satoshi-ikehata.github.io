% x = normal coefficients at a given location to be estimated, 
% A = the lighting location matrix, 
% b = the measurements, and
% lambda = the coefficient of the regularization term.

function [x, error] = min_SBL_error_regularizer(A,b,lambda) % Sparse Basian Learning

MAX_ITERS   = 100;    % Maximum number of iterations
ERR_THR     = 1e-8;   % For stopping criteria
GAMMA_THR   = 1e-8;   % For numerical stability
sigma       = 1.0e6;  % Source variance

[n,m] = size(A);
e_old = 1000*ones(n,1);
gamma = ones(n,1);

for i = 1:MAX_ITERS;
    
    Gamma_e = diag(gamma);
    Sigma_d = gamma + lambda*ones(n,1);
    invD = diag(1./Sigma_d);

    sig_ge = (sigma^(-1)*eye(3) + A'*invD*A)\(A'*invD);
    g_e = (invD - invD*A*sig_ge)*b;
%     g_e = (Gamma_e + lambda*eye(n) + sigma*A*A')\b; % above equation is the deformation of this equation via matrix inversion lemma (for the efficient computation)    
    e = Gamma_e*g_e;
        
    if (norm(e-e_old) < ERR_THR)
        break;        
    end;
    
    e_old = e;    
    
    Ei = (invD - invD*A*sig_ge)*Gamma_e;   
    Sigma_e = Gamma_e - Gamma_e*Ei;
    gamma = diag(e*e') + diag(Sigma_e);
    gamma = max(gamma, GAMMA_THR);
    
end;

Xi = (lambda*eye(n) + Gamma_e + sigma*A*A')\b;
x = sigma*A'*Xi;
error = e;

return;