function [nml, time] = pms_sr(observation, lightings, mask, threshold, lambda, method)
%  Estimate surface normals using sparse regression by Ikehata et al (2012)

[height, width] = size(mask);
m = find(mask(:)==1);
[masklength, numImages]  = size(observation);


n_x = zeros(height*width, 1);
n_y = zeros(height*width, 1);
n_z = zeros(height*width, 1);

tic;
% L1

if method == 0
for i = 1 : length(m)
d = observation(i,:);
d = d';
Omega = find(d>threshold);
d = d(Omega);
L = lightings';
L = L(Omega,:);
x = min_L1_error(L,d);
nm = norm(x);
n_x(m(i))=x(1, 1)/nm;
n_y(m(i))=x(2, 1)/nm;
n_z(m(i))=x(3, 1)/nm;

end

else % SBL
    
for i = 1 : length(m)

d = observation(i,:);
d = d';
Omega = find(d>threshold);
d = d(Omega);
L = lightings';
L = L(Omega,:);

if(lambda == 0)
x = min_SBL_error(L,d);
else
x = min_SBL_error_regularizer(L,d,lambda);
end

nm = norm(x);
n_x(m(i))=x(1, 1)/nm;
n_y(m(i))=x(2, 1)/nm;
n_z(m(i))=x(3, 1)/nm;

% if(mod(i, 1000) == 0)
% i
% end

end
end

n_x = reshape(n_x, height, width);
n_y = reshape(n_y, height, width);
n_z = reshape(n_z, height, width);

nml = zeros(height, width, 3);
nml(:, :, 1) = -n_x;
nml(:, :, 2) = -n_y;
nml(:, :, 3) = -n_z;
nml(isnan(nml)) = 0;

time = toc;
end

