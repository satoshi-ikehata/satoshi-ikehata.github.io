Robust Photometric Stereo Using Sparse Regression
% Robust Photometric Stereo Using Sparse Regression
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp, dvwipf@microsoft.com, yasumat@microsoft.com
% Date: 20120406

This package contains codes and a synthetic dataset used in the paper.

= dataset =
images: Synthesized bunny images (24bit-grayscale-portable-float-map format and image size is 256x256)
lighting: Lighting directions used for rendering
mask.png: Mask image indicating the object region
imgNormal: Ground-truth normal map

=�@useage =
Please run "main.m" in this package.
