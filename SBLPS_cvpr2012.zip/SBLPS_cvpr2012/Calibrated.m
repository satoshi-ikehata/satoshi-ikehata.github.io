function [S, L, S_len] = Calibrated(I, light_show)

[p, f] = size(I); % p is always 1 f is number of images
L = light_show;

S_hat = I * pinv(L);
S = zeros(size(S_hat));
S_len = zeros(p, 1);

signX = 1;
signY = 1; 
signZ = 1;

for i = 1 : p;
    len = sqrt(S_hat(i, 1)*S_hat(i, 1)+S_hat(i, 2)*S_hat(i, 2)+S_hat(i, 3)*S_hat(i, 3));
    S(i, 1) = signX .* (S_hat(i, 1) / len);
    S(i, 2) = signY .* (S_hat(i, 2) / len); 
    S(i, 3) = signZ .* (S_hat(i, 3) / len);
    S_len(i) = len;
end