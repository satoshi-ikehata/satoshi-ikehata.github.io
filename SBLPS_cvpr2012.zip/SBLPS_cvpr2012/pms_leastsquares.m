function [nml, time] = pms_leastsquares(observation, lightings, mask, threshold)
%  Estimate surface normals using the standard least square method by Woodham (1980)

[height, width] = size(mask);
m = find(mask(:)==1);
[masklength, numImages]  = size(observation);

tic;
S_LS = zeros(masklength,3);
for i_row = 1:masklength
   t_col = 1;
   I_temp = [];
   L_temp = []; 
   for j_col = 1:numImages
       if(observation(i_row,j_col) > threshold)
       I_temp (1,t_col) = observation(i_row,j_col);
       L_temp (:,t_col) = lightings(:,j_col);
       t_col = t_col+1;
       end;
   end;

  if t_col <3
       S_temp = zeros(1,3);
   else

    [S_temp, L_t] = Calibrated(I_temp, L_temp);
    
   end;
   S_LS(i_row,:) = S_temp;
end;

n_xLS = zeros(height*width, 1);
n_yLS = zeros(height*width, 1);
n_zLS = zeros(height*width, 1);

for i=1 : length(m);
   n_xLS(m(i))=S_LS(i, 1);
   n_yLS(m(i))=S_LS(i, 2);
   n_zLS(m(i))=S_LS(i, 3);
end;

n_xLS = reshape(n_xLS, height, width);
n_yLS = reshape(n_yLS, height, width);
n_zLS = reshape(n_zLS, height, width);

nml = zeros(height, width, 3);
nml(:, :, 1) = -n_xLS;
nml(:, :, 2) = -n_yLS;
nml(:, :, 3) = -n_zLS;
nml(isnan(nml)) = 0;

time = toc;
end

