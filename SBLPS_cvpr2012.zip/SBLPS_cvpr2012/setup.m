% Robust Photometric Stereo Using Sparse Regression
% Author: Satoshi Ikehata, David Wipf, Yasuyuki Matsushita, Kiyoharu Aizawa
% E_mail: ikehata@hal.t.u-tokyo.ac.jp, dvwipf@microsoft.com,
% yasumat@microsoft.com
% Date: 20120406


%% Setting the parameters
IMAGES           = sprintf('images/%s.pfm','%02d');
LIGHTINGS        = strcat('lighting/L40.mat');
MASK             = sprintf('images/%s.png','mask');
TRUENORMAL       = 'imgNormal.mat';


%% Loading lightings
load(LIGHTINGS);
if(size(L,2) == 3)
    L = L';
end
light_true = L(:,(1:numImages));


%% Loading the true normal map
load(TRUENORMAL);
N_true = imgNormal;


%% Loading the mask image
mask = double(imread(MASK))./255;
mask = mask(:,:,1);
[height, width] = size(mask);
m = find(mask(:)==1);

%% Loading images
I = zeros(length(m), numImages);
for i = 1 : numImages
        img = readPFM(sprintf(IMAGES, i));
        imgR = flipud(img(:,:,1));
        imgG = flipud(img(:,:,2));
        imgB = flipud(img(:,:,3));
        imggray = rgb2gray(imgR,imgG,imgB);
               
        if(noise > 0)
        imgnoise = Box_Muller(size(imggray),0,0.1,noise);       
        imgnoise = imgnoise(m);
        imggray = imggray(m);
        imggray = imggray + imgnoise;
        else
        imggray = imggray(m);
        end
        
        
        I(:, i) = imggray; 
end
