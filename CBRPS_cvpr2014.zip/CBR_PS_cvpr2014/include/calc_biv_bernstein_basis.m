function Be = calc_biv_bernstein_basis(x,y, N1, N2)
% Be = calc_biv_bernstein_basis(x,y, N1, N2)
% compute bivariate bernstein basis polynomials
Be = zeros(length(y), (N1+1)*(N2+1));
Be1 = zeros(length(y), N1+1);
Be2 = zeros(length(y), N2+1);

for k = 0 : N1 % for x
nck = nchoosek(N1,k);
Be1(:,k+1) = nck*x.^(k).*((1-x).^(N1-k));
end

for l = 0 : N2 % for y
nck = nchoosek(N2,l);
Be2(:,l+1) = nck*y.^(l).*((1-y).^(N2-l));
end

for k = 0 : N1
    for l = 0 : N2
        Be(:,k*(N2+1)+l+1) = Be1(:,k+1).*Be2(:,l+1);
    end
end



end

