function [A, b] = calc_biv_bernstein_penalty(N1,N2, retro); 
% [A, b] = calc_biv_bernstein_penalty(N1,N2, retro); 
% compute the penalty matrix for inequality constraints

A1 = zeros(N1*(N2+1),(N1+1)*(N2+1)); 
B = zeros(N2,N2+1);
a = zeros(1,(N1+1)*(N2+1));
b = zeros(1,N2+1);

if nargin==2
retro = 0;
end

if retro == 0
    a(1) =  -1; a(2:N2+1) = 0; a(N2+1+1) = 1; % for the specular reflection (default)
else
    a(1) =  1;  a(2:N2+1) = 0; a(N2+2) = -1; % for the retro reflection
end

b(1) =  -1; b(2) = 1;
A1(1,:) = a;
B(1,:) = b;

for i = 2 : N1*(N2+1);
    a = circshift(a, [0,1]);
    A1(i,:) = a;
end

for i = 2 : N2
    b = circshift(b, [0,1]);
    B(i,:) = b;
end

a2 = cell(1,N1+1);
[a2{:}] = deal(B);
A2 = blkdiag(a2{:});
A = [A1;A2];
b = zeros(size(A,1),1);

end

