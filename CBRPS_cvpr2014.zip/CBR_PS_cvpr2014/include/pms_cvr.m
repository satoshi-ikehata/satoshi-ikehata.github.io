function [nml] = pms_cvr(observation, lightings, N1, N2, retro)
% [nml, a, time] = pms_bvn(observation, lightings, N1, N2, retro)
% Estimate surface normals using constrained bivariate nonparametric regression

nml = zeros(3,1);

%% Setup
I = observation;
L = lightings;
lv = L'*[0,0,1]';
x = lv;     % l^Tv naturally lies in [0,1]
y = I/(max(I)); % normalize I to [0,1]

% calculating bivariate Bernstein polynomial basis
Be = calc_biv_bernstein_basis(x,y,N1,N2); 
C = [L' -Be];   

% inequality constraint: non-negativity + monotonicity
[A, b] = calc_biv_bernstein_penalty(N1, N2); % monotonicity (L8, L9)
B = diag(ones((N1+1)*(N2+1),1)); % non-negativity (L10)
P = [zeros(size(B,1),3),B; zeros(size(A,1),3),A;L', zeros(size(L,2),size(B,2))]; % non-negativity of L'*n is guaranteed since we assume that attached shadows are removed
b = zeros(size(P,1),1);

% equality constraint: boundary constraint + non-zero constraint
d = zeros(size(C,1),1);   
Aeq1 = ones(1,3+(N1+1)*(N2+1)); % passing through y-axis (L11)
Aeq2 = zeros(N1+1,3+(N1+1)*(N2+1)); % avoid degenerate x = 0 solution
for t = 1 : N1+1
tt = 3+(N2+1)*(t-1)+1;
Aeq1(1,tt) = 0;
Aeq2(t,tt) = 1;
end
beq1 = 1;
beq2 = zeros(size(Aeq2,1),1);
Aeq = [Aeq1;Aeq2]; beq = [beq1;beq2];

%% Optimization
% solve the quadratic programing problem (constrained least-squares regression)
% if you want to use lsqlin, please uncomment below
% options  = optimset('LargeScale','off','MaxIter',10000,'Display','off','Diagnostics','off');
% bout = lsqlin(C, d, -P, b, Aeq, beq,[],[],[], options); 

% if you want to use qpc, please uncoment below
H = C'*C;
f = zeros(size(H,2));
bout=qpas(H,f,-P,b,Aeq,beq);


n = bout(1:3); 
sn = 1;  
nm = norm(n);
if abs(n(3))/nm > 5.0e-2
sn = sign(n(3));
end

nml(1)=sn*n(1, 1)/nm;
nml(2)=sn*n(2, 1)/nm;
nml(3)=sn*n(3, 1)/nm;

% retro reflection detection
if retro == 1
    [A2, b] = calc_biv_bernstein_penalty(N1, N2, 1); % calcurating bivariate Bernstein penalty (depending only on N)

    B2 = diag(ones((N1+1)*(N2+1),1));
    P2 = [zeros(size(B2,1),3),B2; zeros(size(A2,1),3),A2;L', zeros(size(L,2),size(B2,2))];
    b2 = zeros(size(P2,1),1);
    
    %     bout2 = lsqlin(C, d, -P2, b2, Aeq, beq,[],[],[],options); 
    bout2 = qpas(H,f,-P2,b2,Aeq,beq);
   
    n2 = bout2(1:3); 
    sn = 1;  
    nm2 = norm(n2);
    if abs(n2(3))/nm2 > 5.0e-2
    sn = sign(n2(3));
    end
    nml2 = sn*n2/nm2;   
    
    q = L'*nml;
    p = q\I;
    q2 = L'*nml2;
    p2 = q2\I;       
    errP = I - p*q;
    errP2 = I - p2*q2;    
    
    Lamberr = sum(abs(errP)-abs(errP2));
    if (Lamberr > 0)
    nml = nml2;
    end  
end

end

