N_CVR = zeros(h*w,3);
N_LS = zeros(h*w,3);

h1 = waitbar(0); 
for i = 1 : length(m) 
observations = I(i,:);
nonshadow = find(observations > 0);
[observations, lights] = threshold(observations(nonshadow), L(:, nonshadow), Tlow); % thresholding

N_CVR(m(i),:) = pms_cvr(observations, lights, N1, N2, retro); % Constrained Bivariate Regression [Ours, CVPR2014]
N_LS(m(i),:) = pms_leastsquares(observations, lights); % Lambertian photometric stereo [Woodham, 1980]
waitbar(double(i)/length(m), h1, 'Computation in progress');
end
close(h1);

N_CVR = reshape(N_CVR, h,w,3);
N_LS = reshape(N_LS, h,w,3);

