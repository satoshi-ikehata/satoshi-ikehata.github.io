function [nml, a, time] = pms_leastsquarespms(observation, lightings)
% [nml, a, time] = pms_leastsquares(observation, lightings, mask, threshold)
% Estimate surface normals using the standard least square method by Woodham (1980)

nml = lightings'\observation;
nm = norm(nml);
nml = nml/nm;

end

