function [I, L] = threshold(I, L, Tlow);
low_max = floor(Tlow*length(I)) ;  
index = zeros(length(I), 2);
index(:,1) = [1:length(I)]';
index(:,2) = I;
index = sortrows(index,2);
obs_ordered = index(:,2);
light_ordered = L(:, index(:,1));
low_index = 1:max(low_max, 3); % Use only Tlow(%) of observations to skip specularities 
I = obs_ordered(low_index);
L = light_ordered(:,low_index);   
end

