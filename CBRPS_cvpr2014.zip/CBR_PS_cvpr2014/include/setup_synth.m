%% Setting the parameters
IMAGES           = sprintf('data/%s/%s.pfm',BRDF,'%02d');
IMAGES_MERL           = sprintf('data/%s/%s.%s.pfm',BRDF,BRDF,'%02d');
LIGHTINGS        = 'data/L300.mat';
MASK             = 'data/mask.png';
TRUENORMAL       = 'data/imgNormal.mat';


%% Loading lightings
load(LIGHTINGS);
if(size(L,2) == 3)
    L = L';
end

if(L(3,1) < 0)
    L = -L;   
end

L = L(:,(1:numImages));

%% Loading the true normal map
load(TRUENORMAL);
[h,w,c] = size(imgNormal);
N_true = imgNormal;
display(sprintf('BRDF: %s', BRDF));
display(sprintf('Num. of images: %d', numImages));
display(sprintf('Size: %d x %d', h,w));
display(sprintf('Tlow: %f', Tlow));
if retro
display('Retro-reflection detection: Yes');
else
display('Retro-reflection detection: No');   
end

%% Loading the mask image
mask = double(imread(MASK))./255;
mask = mask(:,:,1);
[height, width] = size(mask);
m = find(mask(:)==1);

%% Loading images (.pfm)
I = zeros(length(m), numImages);

for i = 1 : numImages
        img = readPFM(sprintf(IMAGES_MERL, i-1));
        imggray = img(:,:,1);    

        imggray = imggray(m);            
        I(:, i) = imggray; 
end
