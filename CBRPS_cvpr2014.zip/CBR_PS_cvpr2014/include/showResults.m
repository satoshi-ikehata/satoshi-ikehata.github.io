% Lambertian photometric stereo (Woodham1980)
figure(1)
subplot(1,2,1)
imagesc(uint8((N_LS+1)*128));
title('Normal (LS)');
axis equal;
axis off;

[meanA_LS, varA_LS, stdA_LS, maxA_LS, angle_LS]  = normalAngleEval(N_true, N_LS, m);
disp(['Avarage anglular error of Lambertian-based method is: ', num2str(meanA_LS)]);

subplot(1,2,2)
AngleMat = zeros(h*w,1);
AngleMat(m) = angle_LS;
AngleMat = reshape(AngleMat, h, w);
imagesc(AngleMat);
caxis([0 10])
title('Error (LS)');
axis equal;
axis off;

% Constrained bibariate regression based photometric stereo (Proposed)
figure(2)
subplot(1,2,1)
imagesc(uint8((N_CVR+1)*128));
title('Normal (CVR)');
axis equal;
axis off;
[meanA_CVR, varA_CVR, stdA_CVR, maxA_CVR, angle_CVR]  = normalAngleEval(N_true, N_CVR, m);
disp(['Avarage anglular error of constrained-bivariate-regression-based method is: ', num2str(meanA_CVR)]);

subplot(1,2,2)
AngleMat = zeros(h*w,1);
AngleMat(m) = angle_CVR;
AngleMat = reshape(AngleMat, h, w);
imagesc(AngleMat);
caxis([0 10])
title('Error (CVR)');
axis equal;
axis off;
