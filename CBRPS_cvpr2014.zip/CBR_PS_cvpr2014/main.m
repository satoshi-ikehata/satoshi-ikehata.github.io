% Robust Photometric Stereo using Constrained Bivariate Regression
% (CVPR2014)
%
% Satoshi Ikehata and Kiyoharu Aizawa
% sikehata@seas.wustl.edu

close all
clear all
addpath 'include'
addpath 'qpc'

%% parameter settings
% Choose BRDF from {'gold-metallic-paint', 'red-fabric'} % note that
% gold-metallic paint is a highly specular object and red-fabric is a
% highly retro reflective object (the retro reflectionh detection (Sec.3 in our paper) is required)
BRDF = 'gold-metallic-paint';

% Dataset parameters
Tlow = 1; % Samples whose intensities are below this threshold are used (Note that this pruning process is applied after the shadow removal)
numImages = 300; % must be less than 300

% Algorithm parameters
N1 = 2; % [Degree of Bernstein polynomials w.r.t l^Tv] - 1 
N2 = 4; % [Degree of Bernstein polynomials w.r.t I] - 1 
retro = 1; % For handling retro reflections set 1 (See section 3 in the paper)

%% load images, lights and mask
setup_synth

%% run photometric stereo algorithms
runPhotometricStereo

%% show results
showResults


