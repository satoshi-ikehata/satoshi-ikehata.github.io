Robust Photometric Stereo Using Constrained Bivariate Regression

% Author: Satoshi Ikehata and Kiyoharu Aizawa
% E_mail: sikehata@seas.wustl.edu

This package contains codes and a synthetic dataset used in the paper.

= dataset =
images: Synthesized sphere images (24bit portable-float-map format and image size is 128x128)
lighting: Lighting directions used for rendering
mask.png: Mask image indicating the object region
imgNormal: Ground-truth normal map

=�@useage =
Please run "main.m" in this package.

= important notice =�@
This package uses the quadratic programming solver by Adrian Wills that is faster than Matlab 'lsqlin' solver
See 'qpc' folder for details 
